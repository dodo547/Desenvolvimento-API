package com.serratec.br.exception;

public class ValorExcpetion extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public ValorExcpetion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



	
}
