package com.serratec.br.entity;


public class SmsRequest {

	private String to;       // Número de telefone de destino
    private String message;  // Mensagem de texto a ser enviada
	
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}





}
