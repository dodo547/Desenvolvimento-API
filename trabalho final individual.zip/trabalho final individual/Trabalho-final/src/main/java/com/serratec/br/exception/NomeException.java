package com.serratec.br.exception;

public class NomeException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public NomeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
