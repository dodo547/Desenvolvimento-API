package com.serratec.br.controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.serratec.br.entity.SmsRequest;
import com.serratec.br.service.TwilioService;

@RestController
public class SMSController {

    private final TwilioService twilioService;

    public SMSController(TwilioService twilioService) {
        this.twilioService = twilioService;
    }

    @PostMapping("/send-sms")
    public void sendSMS(@RequestBody SmsRequest request) {
        twilioService.sendSMS(request.getTo(), request.getMessage());
    }
}